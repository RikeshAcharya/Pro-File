#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 5 // Maximum size of the list

typedef struct {
    int data[MAX_SIZE];
    int size; // Current number of elements in the list
} ArrayList;

// Function to initialize the list
void initList(ArrayList* list) {
    list->size = 0;
}

// Function to display the elements of the list
void displayList(ArrayList* list) {
    if (list->size == 0) {
        printf("The list is empty.\n");
        return;
    }
    printf("List elements: ");
    for (int i = 0; i < list->size; i++) {
        printf("%d ", list->data[i]);
    }
    printf("\n");
}

// Function to insert an element at a specific position
void insertElement(ArrayList* list, int element, int position) {
    if (list->size == MAX_SIZE) {
        printf("List is full. Cannot insert more elements.\n");
        return;
    }
    if (position < 0 || position > list->size) {
        printf("Invalid position. Position should be between 0 and %d.\n", list->size);
        return;
    }
    for (int i = list->size; i > position; i--) {
        list->data[i] = list->data[i - 1];
    }
    list->data[position] = element;
    list->size++;
    printf("Inserted %d at position %d.\n", element, position);
}

// Function to delete an element at a specific position
void deleteElement(ArrayList* list, int position) {
    if (list->size == 0) {
        printf("List is empty. Cannot delete elements.\n");
        return;
    }
    if (position < 0 || position >= list->size) {
        printf("Invalid position. Position should be between 0 and %d.\n", list->size - 1);
        return;
    }
    printf("Deleted %d from position %d.\n", list->data[position], position);
    for (int i = position; i < list->size - 1; i++) {
        list->data[i] = list->data[i + 1];
    }
    list->size--;
}

// Main function to demonstrate the operations with switch case
int main() {
    ArrayList list;
    initList(&list);

    int choice, element, position;

    while (1) {
    	printf("\n Rikesh Acharya \n");
        printf("\n--- Array List Operations ---\n");
        printf("1. Display List\n");
        printf("2. Insert Element\n");
        printf("3. Delete Element\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                displayList(&list);
                break;

            case 2:
                printf("Enter the element to insert: ");
                scanf("%d", &element);
                printf("Enter the position (0 to %d): ", list.size);
                scanf("%d", &position);
                insertElement(&list, element, position);
                break;

            case 3:
                printf("Enter the position to delete (0 to %d): ", list.size - 1);
                scanf("%d", &position);
                deleteElement(&list, position);
                break;

            case 4:
                printf("Exiting program.\n");
                exit(0);

            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}
