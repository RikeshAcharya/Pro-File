#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 5
#define MAX_STRING_LENGTH 100

struct stack{
	char arr[SIZE][MAX_STRING_LENGTH];
	int top;
};
typedef struct stack st;
int initStack(st* s){
	return s->top = -1;
}

int isEmpty(st *s){
	return s->top==-1;
}

int isFull(st *s){
	return s->top==SIZE-1;
}

void push(st *s,char* val){
	if(isFull(s)){
		printf("Stack is full cannot push");
	}else{
		strcpy(s->arr[++s->top],val);
		printf("%s is pushed successufully.",val);
	}
}

void pop(st *s){
	if(isEmpty(s)){
		printf("The Stack is empty");
	}else{
		printf("%s is popped succesfully",s->arr[s->top--]);
	}
}

void peek(st* s){
	if(isEmpty(s)){
		printf("The stack is empty");
	}else{
		printf("Top element of the stack is %s",s->arr[s->top]);
	}
}

void display(st *s){
	if(isEmpty(s)){
		printf("The stack is empty.");
	}else{
		printf("The Element of stack is: ");
		for(int i=0;i<=s->top;i++){
			printf("%s\t",s->arr[i]);
		}
	}
}



int main(){
	int choose;
	char val[MAX_STRING_LENGTH];
	st *s =(st*)malloc(sizeof(st));
	initStack(s);
	while(1){
		printf("\n....Stack menu ....\n");
		printf("\n");
		printf("1. Push the emement on the stack.\n");
		printf("2. Pop the element from the stack.\n");
		printf("3. Display.\n");
		printf("4. Exiting.....\n");
		printf("Enter your choice (1-4): ");
		scanf("%d",&choose);
		switch (choose){
			case 1:
				printf("Enter a character: ");
				scanf("%s",val);
				push(s,val);
				break;
			
			case 2:
				pop(s);
				break;
			
			case 3:
				display(s);
				free(s);
				break;
			case 4:
				printf("Exiting...");
				return;
			default:
				printf("Invalid Synatax.");
		}
	}
}