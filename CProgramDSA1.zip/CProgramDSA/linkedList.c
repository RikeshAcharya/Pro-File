// Singly linked list
#include<stdio.h>
#include<stdlib.h>

struct Node{
int data;
struct Node* next;	
int head;
};
	
typedef struct Node n;
struct Node* createNode(int data){
	struct Node* newNode =(struct Node*)malloc(sizeof(struct Node));
	newNode ->data = data;
	newNode ->next = NULL;
	return newNode;
}


void insertAtBegin(struct Node** head,int data){
	struct Node* newNode = createNode(data);
	newNode ->next = *head;
	*head =newNode;	
}

void insertAtEnd(struct Node** head,int data){
	struct Node* newNode =createNode(data);
	
	if(*head == NULL){
		*head =newNode;
		return;
	}
	struct Node* temp = *head;
	while(temp -> next != NULL){
		temp=temp->next;
	}
	temp ->next =newNode;	
}

void display(struct Node* head){
	struct Node	*temp =head;
	while(temp!=head){
		printf("%d\t",temp->head);
	}
	printf("NULL\n");
}

int main(){
	struct Node* newNode = (struct* Node)malloc(sizeof(struct Node));
	int choice;
	int data;
	while(1){
	
	printf("1. Enter at Begining\n");
	printf("2. Enter at End.\n");
	printf("3. display\n");
	printf("4. Exit");
	printf("Enter your choice (1-4): ");
	scanf("%d\t",choice);
	
	switch(choice){
		case 1:
			printf("Enter a value at begining: ");
			scanf("%d",&data);
			insertAtBegin(head,data);
			break;
		
		case 2:
			printf("Enter a value at the end: ");
			scanf("%d",&data);
			insertAtEnd(data);
			break;
		case 3:
			
			display();
			break;
		case 4:
			printf("Exiting...");
			return;
			
		default:
			printf("Invalid");
	}
	
	
	
	
	
	
}
}
