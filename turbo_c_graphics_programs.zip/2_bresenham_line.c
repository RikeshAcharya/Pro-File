#include <graphics.h>
#include <conio.h>

void bresenham(int x1, int y1, int x2, int y2) {
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int p = 2 * dy - dx;
    int x = x1, y = y1;
    int xend = x2;

    int incx = (x2 > x1) ? 1 : -1;
    int incy = (y2 > y1) ? 1 : -1;

    while (x != x2) {
        putpixel(x, y, WHITE);
        x += incx;
        if (p < 0) {
            p += 2 * dy;
        } else {
            y += incy;
            p += 2 * (dy - dx);
        }
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");
    bresenham(100, 100, 300, 200);
    getch();
    closegraph();
    return 0;
}