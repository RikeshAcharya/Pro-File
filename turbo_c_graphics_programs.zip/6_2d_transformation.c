#include <graphics.h>
#include <conio.h>
#include <math.h>

void drawTriangle(int x[], int y[], int color) {
    setcolor(color);
    line(x[0], y[0], x[1], y[1]);
    line(x[1], y[1], x[2], y[2]);
    line(x[2], y[2], x[0], y[0]);
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int x[3] = {100, 150, 200};
    int y[3] = {150, 100, 150};
    drawTriangle(x, y, WHITE);

    // Translate
    int tx = 100, ty = 50;
    for (int i = 0; i < 3; i++) {
        x[i] += tx;
        y[i] += ty;
    }
    drawTriangle(x, y, GREEN);

    getch();
    closegraph();
    return 0;
}