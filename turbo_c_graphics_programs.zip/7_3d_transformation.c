#include <graphics.h>
#include <conio.h>

void drawCube(int x, int y, int size) {
    rectangle(x, y, x + size, y + size); // front face
    rectangle(x + 30, y - 30, x + size + 30, y + size - 30); // back face

    line(x, y, x + 30, y - 30);
    line(x + size, y, x + size + 30, y - 30);
    line(x, y + size, x + 30, y + size - 30);
    line(x + size, y + size, x + size + 30, y + size - 30);
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");
    drawCube(100, 100, 100);
    getch();
    closegraph();
    return 0;
}