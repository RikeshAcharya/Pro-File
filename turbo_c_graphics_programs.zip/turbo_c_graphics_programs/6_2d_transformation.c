#include <graphics.h>
#include <conio.h>
#include <math.h>

#define PI 3.14159

// Function to draw a triangle
void drawTriangle(int x[], int y[], int color) {
    setcolor(color);
    line(x[0], y[0], x[1], y[1]);
    line(x[1], y[1], x[2], y[2]);
    line(x[2], y[2], x[0], y[0]);
}

// Function to translate a triangle
void translate(int x[], int y[], int tx, int ty, int xt[], int yt[]) {
    for (int i = 0; i < 3; i++) {
        xt[i] = x[i] + tx;
        yt[i] = y[i] + ty;
    }
}

// Function to scale a triangle about first vertex
void scale(int x[], int y[], float sx, float sy, int xs[], int ys[]) {
    for (int i = 0; i < 3; i++) {
        xs[i] = x[0] + int((x[i] - x[0]) * sx);
        ys[i] = y[0] + int((y[i] - y[0]) * sy);
    }
}

// Function to rotate a triangle about first vertex
void rotate(int x[], int y[], float angle, int xr[], int yr[]) {
    for (int i = 0; i < 3; i++) {
        int dx = x[i] - x[0];
        int dy = y[i] - y[0];
        xr[i] = x[0] + int(dx * cos(angle) - dy * sin(angle));
        yr[i] = y[0] + int(dx * sin(angle) + dy * cos(angle));
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\Turboc3\\BGI");  // Set BGI path properly

    int x[3] = {100, 150, 200};
    int y[3] = {150, 100, 150};

    // 1. Original Triangle - White
    drawTriangle(x, y, WHITE);

    // 2. Translated Triangle - Green
    int xt[3], yt[3];
    translate(x, y, 100, 50, xt, yt);
    drawTriangle(xt, yt, GREEN);

    // 3. Scaled Triangle - Blue
    int xs[3], ys[3];
    scale(x, y, 1.5, 1.5, xs, ys);
    drawTriangle(xs, ys, BLUE);

    // 4. Rotated Triangle - Red
    int xr[3], yr[3];
    float angle = 45.0 * PI / 180.0;
    rotate(x, y, angle, xr, yr);
    drawTriangle(xr, yr, RED);

    // 5. Final transformation: Scale + Rotate + Translate - Yellow
    int xf[3], yf[3];
    for (int i = 0; i < 3; i++) {
        // Scale about first point
        float sx1 = (x[i] - x[0]) * 1.5;
        float sy1 = (y[i] - y[0]) * 1.5;

        // Rotate about first point
        float xr1 = sx1 * cos(angle) - sy1 * sin(angle);
        float yr1 = sx1 * sin(angle) + sy1 * cos(angle);

        // Translate
        xf[i] = x[0] + int(xr1) + 200;
        yf[i] = y[0] + int(yr1) + 50;
    }
    drawTriangle(xf, yf, YELLOW);

    getch();
    closegraph();
    return 0;
}
